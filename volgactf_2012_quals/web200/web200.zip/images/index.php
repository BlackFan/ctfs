<?php
	header('Location: ..');
?>